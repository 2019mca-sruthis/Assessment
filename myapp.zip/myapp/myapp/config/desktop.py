from frappe import _

def get_data():
	return [
		{
			"module_name": "Myapp",
			"type": "module",
			"label": _("Myapp")
		}
	]
