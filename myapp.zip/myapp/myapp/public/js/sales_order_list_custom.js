frappe.listview_settings['Sales Order'] = {
    add_fields: ["base_grand_total", "customer_name", "currency", "delivery_date",
		"per_delivered", "per_billed", "status", "order_type", "name", "skip_delivery_note"],
    button: {
        show: function(doc) {
            return true;
        },
        get_label: function() {
            return __('Sales Order');
        },
        get_description: function(doc) {
            return __('Print {0}', [doc.name])
        },
		action: function(doc) {
			//    frappe.msgprint("hiiiii")
			var sales_order =doc.name
			// console.log(sales_order)
			// var order_type= doc.order_type
            // var s = 
			// console.log(order_type)
			frappe.msgprint({
				title: __('Sales Order Details'),
				message:("Sales Order Id:" + sales_order + "<br>Sales Order Type:"+ doc.order_type)
               
			})
         
            }
		}
}